package Practice9;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.Vector;

public class ClientA {
	
	Socket socket;
	
	int primnum1, primnum2;
	int n;
	int a;
	int result1,result2,result_final;
	
	PrintWriter out;
	BufferedReader in;
	
	public void job()
	{
		try
		{
			
			socket = new Socket("127.0.0.1",6666);
		
			out = new PrintWriter(socket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			
			Scanner scan = new Scanner(System.in);
			
			System.out.println("ū �Ҽ� 2���� �Է��ϼ���");
			
			primnum1 = scan.nextInt();
			primnum2 = scan.nextInt();
			
			n = primnum1*primnum2;
			
			out.println(n);
			
			a = Integer.parseInt(in.readLine());

			china();
						
			System.out.println("4���� ������ �Ѱ��� �����ϼ���");
					
			Vector vec = new Vector();
			
			for(int i = 0 ; i < n ; ++i)
			{
				if(a == (i*i % n))
				{
					System.out.print(i + " ");
					vec.add(i);
				}
			}
			
			int selected;
			
			System.out.println("");
			
			selected = scan.nextInt();
						
			for(int i = 0 ; i < vec.size() ; ++i)
			{
				if(selected == (int)vec.elementAt(i))
				{					
					out.println(selected);
				}
			}
			
			String result = in.readLine();
			
			System.out.print(result);
			
//			while(true){}
						
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	private void china()
	{
		
	}
	
	public static void main(String[] args)
	{
		ClientA c = new ClientA();
		c.job();
	}

}
